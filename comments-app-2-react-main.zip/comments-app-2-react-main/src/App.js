import Comments from './components/Comments'

import './App.css'

const App = () => <Comments />

export default App
